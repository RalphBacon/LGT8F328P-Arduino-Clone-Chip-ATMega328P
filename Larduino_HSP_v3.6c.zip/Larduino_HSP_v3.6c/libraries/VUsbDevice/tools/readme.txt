// build note:
// ==============================================================
Winddk headers is needed to build hidtool, Mingw is recommended cuz
it installed with a free version winddk library.
Remeber to select winddk and msys.

After installation of mingw, start msys, we now get ready.
inside msys console, redirect to hidtools directory, type and run:
>> make -f Makefile.windows 

// well, good luck.

// LGT devgroup.